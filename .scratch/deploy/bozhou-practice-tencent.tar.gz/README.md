# 亳州网络部在线刷题 · 通用在线刷题网站

管理员统一发布题库，学习者使用用户名和密码登录。支持手机与电脑续刷、CSV/XLSX 模板导入、单选/多选/判断、顺序/随机/错题/收藏练习，以及题目版本和个人学习记录。

## 前端构建

前端使用 React、Tailwind v4 与 shadcn/ui（Radix）。首次启动前构建：

```powershell
Set-Location frontend
npm ci
npm run build
Set-Location ..
```

构建产物在 `web/build/`，由 FastAPI 同源提供，避免跨域认证。开发时可在前端目录运行 `npm run dev`，开发服务器代理 API 到本地8000端口。源码渲染层集中于 `frontend/src/surface.tsx`，通过组件适配保留现有控制器命令及事件协议。

## 本地启动（PowerShell）

```powershell
python -m venv .venv
.venv/Scripts/python.exe -m pip install -r requirements.txt
$env:ADMIN_USERNAME = 'admin'
$taskAdminCredential = Read-Host '首位管理员密码（至少10字符）' -AsSecureString
$env:ADMIN_PASSWORD = [System.Net.NetworkCredential]::new('', $taskAdminCredential).Password
.venv/Scripts/python.exe -m uvicorn app:app --host 127.0.0.1 --port 8000
```

打开 http://127.0.0.1:8000 。首次启动创建管理员，后续不会用环境变量覆盖现有密码。关闭后可清除当前终端的 `ADMIN_PASSWORD` 环境变量。数据库默认在 `data/practice.db`，刷新或重启不会丢失记录。正式服务没有内置题库或默认密码。

## 导入与发布

管理员登录后新建题库，下载 CSV 或 Excel 模板。表头须完全一致：编号、题型、题干、A、B、C、D、E、答案、解析、分类、标签。解析、分类、标签可空；答案用 A–E，多选用 `A|C`，判断填“正确”或“错误”。题目编号在同一题库内唯一且稳定。CSV 使用 UTF-8，可含按 CSV 规则引用的逗号和换行；Excel 公式不接受。

全量校验后预览前10题并显示新增/更新数量，确认保存草稿，再确认发布。存在错误时整批不保存。重新导入不删除文件中缺少的旧题。编辑或归档题目也需发布，历史练习固定旧版本。

## 测试与检查

```powershell
.venv/Scripts/python.exe -m pytest -q
.venv/Scripts/python.exe -m mypy app.py ops/backup.py --check-untyped-defs --ignore-missing-imports
npm --prefix frontend run typecheck
```

测试通过公开 API 和真实临时数据库验证行为；浏览器验收结果见项目验证记录。测试账号只存在于临时数据库。

## Docker 与 HTTPS

复制 `.env.example` 为 `.env`，设置实际域名、管理员用户名及随机强密码，域名 DNS 指向服务器，开放80/443端口，运行 `docker compose up -d --build`。Caddy 自动取得 HTTPS 证书；应用不直接暴露端口，生产 cookie 仅通过 HTTPS 发送。数据库与 Caddy 数据位于命名卷。备份容器启动后执行首次备份，以后每24小时备份一次，保留最近14份。上线前验证域名、证书、管理员登录与两台真实设备续刷。

本实现使用 SQLite，适用于单应用实例；不要横向扩展多个应用容器。定期将备份另存到服务器之外，并检查备份容器日志及磁盘空间。

## 备份和恢复

本地备份：`.venv/Scripts/python.exe ops/backup.py once`。备份使用 SQLite 在线备份接口并验证完整性，不直接复制运行中的数据库文件。

恢复前停止应用、额外备份当前库。指定 `DATABASE` 为目标后运行 `.venv/Scripts/python.exe ops/backup.py restore --file backups/<备份文件>.db`。恢复后所有账号重新登录，学习数据保留。

Docker 恢复：先 `docker compose stop app backup`，把备份保留在备份卷，执行 `docker compose run --rm --no-deps backup python ops/backup.py restore --file /backups/<备份文件>.db`，最后 `docker compose up -d app backup`。恢复完成后检查用户、题库、历史记录及统计。不要在运行中的应用上恢复。


## 两个角色与独立界面

- `/admin`：管理员后台，包含管理概览、题库导入与发布、人员密码重置及反馈处理。管理员视图在 frontend/src/admin-view.js。
- `/learn`：普通人员工作台，包含题库、练习、历史、错题、收藏与个人反馈。学习视图在 frontend/src/learner-view.js。
- 账号角色由服务端登录结果决定；打开某个地址不会获得对应权限。登录后自动进入自己的工作区，普通注册只创建普通人员。管理员仍由首次启动配置创建。
- 管理员界面不加载个人练习和错题数据；管理概览使用受服务端管理员权限保护的独立统计接口。普通人员只能读取自己的学习记录和已发布题库。


## 批量删除题目

管理员在题库管理中展开题目列表，勾选题目或全选后点击“删除所选题目”；“删除全部题目”会处理该题库全部未归档题目。确认弹窗显示数量，确认后保存归档草稿，点击“确认发布”才生效。题目不进入新练习，已有会话和历史记录保留。空选择不会执行；并发版本变化要求刷新；请求含不存在的题目时整批拒绝。
